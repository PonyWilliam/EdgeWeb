<template>
  <BaseHeader />
  <div style="display: flex">
    <BaseSide />
    <div>
      <HelloWorld/>
    </div>
  </div>
</template>

<style>
#app {
  text-align: center;
}

.element-plus-logo {
  width: 50%;
}
</style>
